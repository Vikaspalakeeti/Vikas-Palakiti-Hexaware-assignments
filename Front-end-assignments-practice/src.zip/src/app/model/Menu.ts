export class Menu{
    menuItemId:number=0;
  restaurantId:number=0;
  itemName:String='';
  description:String='';
  price:number= 0;
}