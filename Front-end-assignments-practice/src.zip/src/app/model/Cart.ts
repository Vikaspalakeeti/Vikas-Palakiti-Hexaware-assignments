export class Cart{
    
   cartId:number=0;
   customerId:number=0;
   restaurantId:number=0;
   itemId:number[]=[];
   price:number=0;
   quantity:number=0;
   total:number=0;
   
	
}
