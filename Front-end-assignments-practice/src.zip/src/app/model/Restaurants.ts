export class Restaurants{
    
    restaurantId:number=0;
	restaurantName:string='';
    cuisineType:string='';
    location:string='';
    rating:number=0;  
    // customerIds: [] | undefined  
    
 }
 