export class Customer
{
    customerId:number= 0;
    customerName:string='';
    email:string='';
    phoneNumber:String='';
    deliveryAddress:string='';
    password:string='';
  }