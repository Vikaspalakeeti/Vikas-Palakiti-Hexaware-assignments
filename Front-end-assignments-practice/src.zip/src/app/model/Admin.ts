export class Admin{
    adminId:number=0;
    userName:string='';
    password:string='';
}