export class Orders
{
    cartId:number= 0;
    customerId:number= 0;
    restaurantId:number= 0;
    deliveryAddress:String= "";
    paymentMethod:string= "";
    totalAmount:number=0
  }