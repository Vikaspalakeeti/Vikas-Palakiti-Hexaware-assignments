import { Component } from '@angular/core';
import { Admin } from 'src/app/model/Admin';
import { AdminService } from 'src/app/services/admin.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  constructor(private  admService:AdminService){}




 
 






}
